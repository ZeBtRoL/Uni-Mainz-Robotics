# __init__.py
from .AlphaBot2 import AlphaBot2
from .InfraredSensor import InfraredSensor