# Uni-Mainz-Robotics
This is a repository for my team in Robotics, where we have to develop different scripts for our Raspberry Pi robot.
